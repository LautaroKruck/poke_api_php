<!-- footer.php -->
<footer>
    <p>&copy; 2025 Mi Página Web. Todos los derechos reservados.</p>
</footer>

