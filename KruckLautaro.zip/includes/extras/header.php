<!-- header.php -->

    <header>
        <h1><a href="api.php">Pokédex App</a></h1>
        <nav>
            <a href="index.php">Login</a>
            <a href="register.php">Registro</a>
        </nav>
    </header>
